﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Form1;

namespace WindowsFormsApplication1
{
    public partial class Form6 : Form
    {
        private int playerCount;
        private Form1.Menu mainmenu1;
        public int i = 1;
        public int count = 0;
        public string[] playersPieces = new string[5]; //array that holds piece selection for each player

        public void selectPiece()
        {
            if (i <= playerCount)
            {
                textBox1.Text = "Player" + " " + i;
                i++;
                count++; 
            }
      

        }

        public Form6(int playerCount, Form1.Menu mainmenu1) 
        {
            InitializeComponent();
            button2.Enabled = false;
            this.playerCount = playerCount;
            this.mainmenu1 = mainmenu1;
            selectPiece();
        }

        private void button1_Click(object sender, EventArgs e) //cancel button
        {
            mainmenu1.Show(); //open main menu screen
            this.Close();
           
        }

        private void button2_Click(object sender, EventArgs e) //next button
        {
            button2.Enabled = false;
            if (count < playerCount)
            {
                selectPiece(); //next player
                
            }

            else if (count == playerCount) //if all players have selected
            {
                string playerCountS = playerCount.ToString();
                Form4 form4 = new Form4(playerCountS, mainmenu1, playersPieces,playerCount); 
                form4.Show(); //open game screen
                this.Hide();

            }
           
            if(checkBox1.Checked == true)
            {
                checkBox1.Enabled = false;
            }
            if (checkBox2.Checked == true)
            {
                checkBox2.Enabled = false;
            }
            if (checkBox3.Checked == true)
            {
                checkBox3.Enabled = false;
            }
            if (checkBox4.Checked == true)
            {
                checkBox4.Enabled = false;
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                button2.Enabled = true; //Enable next button once piece is selected
                playersPieces[count] = "Ghost";
                checkBox2.Checked = false;
                checkBox3.Checked = false;
                checkBox4.Checked = false;
            }

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked == true)
            {
                button2.Enabled = true; 
                playersPieces[count] = "Hat";
                checkBox1.Checked = false;
                checkBox3.Checked = false;
                checkBox4.Checked = false;
            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked == true)
            {
                button2.Enabled = true;
                playersPieces[count] = "Pumpkin";
                checkBox1.Checked = false;
                checkBox2.Checked = false;
                checkBox4.Checked = false;
            }   
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked == true)
            {
                button2.Enabled = true;
                playersPieces[count] = "Skull";
                checkBox1.Checked = false;
                checkBox2.Checked = false;
                checkBox3.Checked = false;
            }
        }

        private void Form6_Load(object sender, EventArgs e)
        {

        }

     
    }
}
