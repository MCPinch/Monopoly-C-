﻿namespace Form1
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form4));
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.richTextBox3 = new System.Windows.Forms.RichTextBox();
            this.richTextBox4 = new System.Windows.Forms.RichTextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.displayText = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.richTextBox5 = new System.Windows.Forms.RichTextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.tile0 = new System.Windows.Forms.PictureBox();
            this.tile1 = new System.Windows.Forms.PictureBox();
            this.tile2 = new System.Windows.Forms.PictureBox();
            this.tile3 = new System.Windows.Forms.PictureBox();
            this.tile4 = new System.Windows.Forms.PictureBox();
            this.tile5 = new System.Windows.Forms.PictureBox();
            this.tile6 = new System.Windows.Forms.PictureBox();
            this.tile7 = new System.Windows.Forms.PictureBox();
            this.tile8 = new System.Windows.Forms.PictureBox();
            this.tile9 = new System.Windows.Forms.PictureBox();
            this.tile10 = new System.Windows.Forms.PictureBox();
            this.tile11 = new System.Windows.Forms.PictureBox();
            this.tile12 = new System.Windows.Forms.PictureBox();
            this.tile13 = new System.Windows.Forms.PictureBox();
            this.tile14 = new System.Windows.Forms.PictureBox();
            this.tile15 = new System.Windows.Forms.PictureBox();
            this.tile16 = new System.Windows.Forms.PictureBox();
            this.tile17 = new System.Windows.Forms.PictureBox();
            this.tile18 = new System.Windows.Forms.PictureBox();
            this.tile19 = new System.Windows.Forms.PictureBox();
            this.tile20 = new System.Windows.Forms.PictureBox();
            this.tile21 = new System.Windows.Forms.PictureBox();
            this.tile22 = new System.Windows.Forms.PictureBox();
            this.tile23 = new System.Windows.Forms.PictureBox();
            this.tile24 = new System.Windows.Forms.PictureBox();
            this.tile25 = new System.Windows.Forms.PictureBox();
            this.tile26 = new System.Windows.Forms.PictureBox();
            this.tile27 = new System.Windows.Forms.PictureBox();
            this.tile28 = new System.Windows.Forms.PictureBox();
            this.tile29 = new System.Windows.Forms.PictureBox();
            this.tile30 = new System.Windows.Forms.PictureBox();
            this.tile31 = new System.Windows.Forms.PictureBox();
            this.tile32 = new System.Windows.Forms.PictureBox();
            this.tile33 = new System.Windows.Forms.PictureBox();
            this.tile34 = new System.Windows.Forms.PictureBox();
            this.tile35 = new System.Windows.Forms.PictureBox();
            this.tile36 = new System.Windows.Forms.PictureBox();
            this.tile37 = new System.Windows.Forms.PictureBox();
            this.tile38 = new System.Windows.Forms.PictureBox();
            this.tile39 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile30)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile37)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile38)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile39)).BeginInit();
            this.SuspendLayout();
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(295, 659);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.ReadOnly = true;
            this.richTextBox1.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.richTextBox1.Size = new System.Drawing.Size(100, 96);
            this.richTextBox1.TabIndex = 1;
            this.richTextBox1.Text = "";
            // 
            // richTextBox2
            // 
            this.richTextBox2.Location = new System.Drawing.Point(427, 659);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.ReadOnly = true;
            this.richTextBox2.Size = new System.Drawing.Size(100, 96);
            this.richTextBox2.TabIndex = 2;
            this.richTextBox2.Text = "";
            // 
            // richTextBox3
            // 
            this.richTextBox3.Location = new System.Drawing.Point(558, 659);
            this.richTextBox3.Name = "richTextBox3";
            this.richTextBox3.ReadOnly = true;
            this.richTextBox3.Size = new System.Drawing.Size(100, 96);
            this.richTextBox3.TabIndex = 3;
            this.richTextBox3.Text = "";
            // 
            // richTextBox4
            // 
            this.richTextBox4.Location = new System.Drawing.Point(698, 659);
            this.richTextBox4.Name = "richTextBox4";
            this.richTextBox4.ReadOnly = true;
            this.richTextBox4.Size = new System.Drawing.Size(100, 96);
            this.richTextBox4.TabIndex = 4;
            this.richTextBox4.Text = "";
            // 
            // button1
            // 
            this.button1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button1.Location = new System.Drawing.Point(267, 185);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(144, 56);
            this.button1.TabIndex = 5;
            this.button1.Text = "Roll";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(485, 185);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(136, 56);
            this.button2.TabIndex = 6;
            this.button2.Text = "Buy";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(665, 185);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(133, 56);
            this.button3.TabIndex = 7;
            this.button3.Text = "Draw Card";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(485, 290);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(136, 53);
            this.button4.TabIndex = 8;
            this.button4.Text = "Quit";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(665, 290);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(133, 57);
            this.button5.TabIndex = 9;
            this.button5.Text = "End Turn";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // displayText
            // 
            this.displayText.Location = new System.Drawing.Point(453, 452);
            this.displayText.Multiline = true;
            this.displayText.Name = "displayText";
            this.displayText.ReadOnly = true;
            this.displayText.Size = new System.Drawing.Size(100, 20);
            this.displayText.TabIndex = 10;
            // 
            // textBox1
            // 
            this.textBox1.AcceptsReturn = true;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(295, 508);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(446, 67);
            this.textBox1.TabIndex = 11;
            // 
            // richTextBox5
            // 
            this.richTextBox5.Location = new System.Drawing.Point(183, 399);
            this.richTextBox5.Name = "richTextBox5";
            this.richTextBox5.ReadOnly = true;
            this.richTextBox5.Size = new System.Drawing.Size(100, 96);
            this.richTextBox5.TabIndex = 12;
            this.richTextBox5.Text = "";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.Ghost;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(830, 869);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(78, 58);
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.Hat;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Default;
            this.pictureBox2.Location = new System.Drawing.Point(830, 869);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(90, 65);
            this.pictureBox2.TabIndex = 14;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.Pumpkin;
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox3.Location = new System.Drawing.Point(830, 876);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(78, 58);
            this.pictureBox3.TabIndex = 15;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox4.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox4.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.Skull;
            this.pictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox4.Cursor = System.Windows.Forms.Cursors.Default;
            this.pictureBox4.Location = new System.Drawing.Point(830, 876);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(78, 58);
            this.pictureBox4.TabIndex = 16;
            this.pictureBox4.TabStop = false;
            // 
            // tile0
            // 
            this.tile0.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tile0.BackColor = System.Drawing.Color.Transparent;
            this.tile0.Location = new System.Drawing.Point(830, 869);
            this.tile0.Name = "tile0";
            this.tile0.Size = new System.Drawing.Size(110, 121);
            this.tile0.TabIndex = 17;
            this.tile0.TabStop = false;
            // 
            // tile1
            // 
            this.tile1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tile1.BackColor = System.Drawing.Color.Transparent;
            this.tile1.Location = new System.Drawing.Point(748, 868);
            this.tile1.Name = "tile1";
            this.tile1.Size = new System.Drawing.Size(76, 121);
            this.tile1.TabIndex = 18;
            this.tile1.TabStop = false;
            // 
            // tile2
            // 
            this.tile2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tile2.BackColor = System.Drawing.Color.Transparent;
            this.tile2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.tile2.Location = new System.Drawing.Point(675, 869);
            this.tile2.MaximumSize = new System.Drawing.Size(67, 121);
            this.tile2.MinimumSize = new System.Drawing.Size(67, 121);
            this.tile2.Name = "tile2";
            this.tile2.Size = new System.Drawing.Size(67, 121);
            this.tile2.TabIndex = 19;
            this.tile2.TabStop = false;
            // 
            // tile3
            // 
            this.tile3.BackColor = System.Drawing.Color.Transparent;
            this.tile3.Location = new System.Drawing.Point(595, 868);
            this.tile3.Name = "tile3";
            this.tile3.Size = new System.Drawing.Size(74, 121);
            this.tile3.TabIndex = 20;
            this.tile3.TabStop = false;
            // 
            // tile4
            // 
            this.tile4.BackColor = System.Drawing.Color.Transparent;
            this.tile4.Location = new System.Drawing.Point(518, 868);
            this.tile4.Name = "tile4";
            this.tile4.Size = new System.Drawing.Size(71, 121);
            this.tile4.TabIndex = 21;
            this.tile4.TabStop = false;
            // 
            // tile5
            // 
            this.tile5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tile5.BackColor = System.Drawing.Color.Transparent;
            this.tile5.Location = new System.Drawing.Point(440, 869);
            this.tile5.Name = "tile5";
            this.tile5.Size = new System.Drawing.Size(72, 121);
            this.tile5.TabIndex = 22;
            this.tile5.TabStop = false;
            // 
            // tile6
            // 
            this.tile6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tile6.BackColor = System.Drawing.Color.Transparent;
            this.tile6.Location = new System.Drawing.Point(363, 869);
            this.tile6.Name = "tile6";
            this.tile6.Size = new System.Drawing.Size(82, 121);
            this.tile6.TabIndex = 23;
            this.tile6.TabStop = false;
            // 
            // tile7
            // 
            this.tile7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tile7.BackColor = System.Drawing.Color.Transparent;
            this.tile7.Location = new System.Drawing.Point(286, 869);
            this.tile7.Name = "tile7";
            this.tile7.Size = new System.Drawing.Size(71, 121);
            this.tile7.TabIndex = 24;
            this.tile7.TabStop = false;
            // 
            // tile8
            // 
            this.tile8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tile8.BackColor = System.Drawing.Color.Transparent;
            this.tile8.Location = new System.Drawing.Point(214, 869);
            this.tile8.Name = "tile8";
            this.tile8.Size = new System.Drawing.Size(69, 121);
            this.tile8.TabIndex = 25;
            this.tile8.TabStop = false;
            // 
            // tile9
            // 
            this.tile9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tile9.BackColor = System.Drawing.Color.Transparent;
            this.tile9.Location = new System.Drawing.Point(135, 869);
            this.tile9.Name = "tile9";
            this.tile9.Size = new System.Drawing.Size(73, 121);
            this.tile9.TabIndex = 26;
            this.tile9.TabStop = false;
            // 
            // tile10
            // 
            this.tile10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tile10.BackColor = System.Drawing.Color.Transparent;
            this.tile10.Location = new System.Drawing.Point(12, 869);
            this.tile10.Name = "tile10";
            this.tile10.Size = new System.Drawing.Size(117, 121);
            this.tile10.TabIndex = 27;
            this.tile10.TabStop = false;
            // 
            // tile11
            // 
            this.tile11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tile11.BackColor = System.Drawing.Color.Transparent;
            this.tile11.Location = new System.Drawing.Point(12, 784);
            this.tile11.Name = "tile11";
            this.tile11.Size = new System.Drawing.Size(117, 79);
            this.tile11.TabIndex = 28;
            this.tile11.TabStop = false;
            // 
            // tile12
            // 
            this.tile12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tile12.BackColor = System.Drawing.Color.Transparent;
            this.tile12.Location = new System.Drawing.Point(12, 706);
            this.tile12.Name = "tile12";
            this.tile12.Size = new System.Drawing.Size(117, 72);
            this.tile12.TabIndex = 29;
            this.tile12.TabStop = false;
            // 
            // tile13
            // 
            this.tile13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tile13.BackColor = System.Drawing.Color.Transparent;
            this.tile13.Location = new System.Drawing.Point(12, 626);
            this.tile13.Name = "tile13";
            this.tile13.Size = new System.Drawing.Size(117, 74);
            this.tile13.TabIndex = 30;
            this.tile13.TabStop = false;
            // 
            // tile14
            // 
            this.tile14.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tile14.BackColor = System.Drawing.Color.Transparent;
            this.tile14.Location = new System.Drawing.Point(12, 547);
            this.tile14.Name = "tile14";
            this.tile14.Size = new System.Drawing.Size(117, 83);
            this.tile14.TabIndex = 31;
            this.tile14.TabStop = false;
            // 
            // tile15
            // 
            this.tile15.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tile15.BackColor = System.Drawing.Color.Transparent;
            this.tile15.Location = new System.Drawing.Point(12, 465);
            this.tile15.Name = "tile15";
            this.tile15.Size = new System.Drawing.Size(117, 76);
            this.tile15.TabIndex = 32;
            this.tile15.TabStop = false;
            // 
            // tile16
            // 
            this.tile16.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tile16.BackColor = System.Drawing.Color.Transparent;
            this.tile16.Location = new System.Drawing.Point(13, 388);
            this.tile16.Name = "tile16";
            this.tile16.Size = new System.Drawing.Size(116, 71);
            this.tile16.TabIndex = 33;
            this.tile16.TabStop = false;
            // 
            // tile17
            // 
            this.tile17.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tile17.BackColor = System.Drawing.Color.Transparent;
            this.tile17.Location = new System.Drawing.Point(12, 307);
            this.tile17.Name = "tile17";
            this.tile17.Size = new System.Drawing.Size(117, 75);
            this.tile17.TabIndex = 34;
            this.tile17.TabStop = false;
            // 
            // tile18
            // 
            this.tile18.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tile18.BackColor = System.Drawing.Color.Transparent;
            this.tile18.Location = new System.Drawing.Point(12, 228);
            this.tile18.Name = "tile18";
            this.tile18.Size = new System.Drawing.Size(117, 73);
            this.tile18.TabIndex = 35;
            this.tile18.TabStop = false;
            // 
            // tile19
            // 
            this.tile19.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tile19.BackColor = System.Drawing.Color.Transparent;
            this.tile19.Location = new System.Drawing.Point(12, 152);
            this.tile19.Name = "tile19";
            this.tile19.Size = new System.Drawing.Size(117, 70);
            this.tile19.TabIndex = 36;
            this.tile19.TabStop = false;
            // 
            // tile20
            // 
            this.tile20.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tile20.BackColor = System.Drawing.Color.Transparent;
            this.tile20.Location = new System.Drawing.Point(12, 24);
            this.tile20.Name = "tile20";
            this.tile20.Size = new System.Drawing.Size(117, 122);
            this.tile20.TabIndex = 37;
            this.tile20.TabStop = false;
            // 
            // tile21
            // 
            this.tile21.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tile21.BackColor = System.Drawing.Color.Transparent;
            this.tile21.Location = new System.Drawing.Point(135, 24);
            this.tile21.Name = "tile21";
            this.tile21.Size = new System.Drawing.Size(73, 122);
            this.tile21.TabIndex = 38;
            this.tile21.TabStop = false;
            // 
            // tile22
            // 
            this.tile22.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tile22.BackColor = System.Drawing.Color.Transparent;
            this.tile22.Location = new System.Drawing.Point(215, 24);
            this.tile22.Name = "tile22";
            this.tile22.Size = new System.Drawing.Size(68, 122);
            this.tile22.TabIndex = 39;
            this.tile22.TabStop = false;
            // 
            // tile23
            // 
            this.tile23.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tile23.BackColor = System.Drawing.Color.Transparent;
            this.tile23.Location = new System.Drawing.Point(286, 24);
            this.tile23.Name = "tile23";
            this.tile23.Size = new System.Drawing.Size(71, 122);
            this.tile23.TabIndex = 40;
            this.tile23.TabStop = false;
            // 
            // tile24
            // 
            this.tile24.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tile24.BackColor = System.Drawing.Color.Transparent;
            this.tile24.Location = new System.Drawing.Point(364, 24);
            this.tile24.Name = "tile24";
            this.tile24.Size = new System.Drawing.Size(81, 122);
            this.tile24.TabIndex = 41;
            this.tile24.TabStop = false;
            // 
            // tile25
            // 
            this.tile25.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tile25.BackColor = System.Drawing.Color.Transparent;
            this.tile25.Location = new System.Drawing.Point(440, 24);
            this.tile25.Name = "tile25";
            this.tile25.Size = new System.Drawing.Size(72, 122);
            this.tile25.TabIndex = 42;
            this.tile25.TabStop = false;
            // 
            // tile26
            // 
            this.tile26.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tile26.BackColor = System.Drawing.Color.Transparent;
            this.tile26.Location = new System.Drawing.Point(519, 24);
            this.tile26.Name = "tile26";
            this.tile26.Size = new System.Drawing.Size(70, 122);
            this.tile26.TabIndex = 43;
            this.tile26.TabStop = false;
            // 
            // tile27
            // 
            this.tile27.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tile27.BackColor = System.Drawing.Color.Transparent;
            this.tile27.Location = new System.Drawing.Point(595, 24);
            this.tile27.Name = "tile27";
            this.tile27.Size = new System.Drawing.Size(74, 122);
            this.tile27.TabIndex = 44;
            this.tile27.TabStop = false;
            // 
            // tile28
            // 
            this.tile28.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tile28.BackColor = System.Drawing.Color.Transparent;
            this.tile28.Location = new System.Drawing.Point(675, 24);
            this.tile28.Name = "tile28";
            this.tile28.Size = new System.Drawing.Size(67, 122);
            this.tile28.TabIndex = 45;
            this.tile28.TabStop = false;
            // 
            // tile29
            // 
            this.tile29.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tile29.BackColor = System.Drawing.Color.Transparent;
            this.tile29.Location = new System.Drawing.Point(748, 24);
            this.tile29.Name = "tile29";
            this.tile29.Size = new System.Drawing.Size(76, 122);
            this.tile29.TabIndex = 46;
            this.tile29.TabStop = false;
            // 
            // tile30
            // 
            this.tile30.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tile30.BackColor = System.Drawing.Color.Transparent;
            this.tile30.Location = new System.Drawing.Point(830, 24);
            this.tile30.Name = "tile30";
            this.tile30.Size = new System.Drawing.Size(110, 122);
            this.tile30.TabIndex = 47;
            this.tile30.TabStop = false;
            // 
            // tile31
            // 
            this.tile31.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tile31.BackColor = System.Drawing.Color.Transparent;
            this.tile31.Location = new System.Drawing.Point(830, 152);
            this.tile31.Name = "tile31";
            this.tile31.Size = new System.Drawing.Size(110, 70);
            this.tile31.TabIndex = 48;
            this.tile31.TabStop = false;
            // 
            // tile32
            // 
            this.tile32.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tile32.BackColor = System.Drawing.Color.Transparent;
            this.tile32.Location = new System.Drawing.Point(830, 229);
            this.tile32.Name = "tile32";
            this.tile32.Size = new System.Drawing.Size(110, 72);
            this.tile32.TabIndex = 49;
            this.tile32.TabStop = false;
            // 
            // tile33
            // 
            this.tile33.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tile33.BackColor = System.Drawing.Color.Transparent;
            this.tile33.Location = new System.Drawing.Point(830, 308);
            this.tile33.Name = "tile33";
            this.tile33.Size = new System.Drawing.Size(110, 74);
            this.tile33.TabIndex = 50;
            this.tile33.TabStop = false;
            // 
            // tile34
            // 
            this.tile34.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tile34.BackColor = System.Drawing.Color.Transparent;
            this.tile34.Location = new System.Drawing.Point(830, 388);
            this.tile34.Name = "tile34";
            this.tile34.Size = new System.Drawing.Size(110, 71);
            this.tile34.TabIndex = 51;
            this.tile34.TabStop = false;
            // 
            // tile35
            // 
            this.tile35.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tile35.BackColor = System.Drawing.Color.Transparent;
            this.tile35.Location = new System.Drawing.Point(830, 466);
            this.tile35.Name = "tile35";
            this.tile35.Size = new System.Drawing.Size(110, 75);
            this.tile35.TabIndex = 52;
            this.tile35.TabStop = false;
            // 
            // tile36
            // 
            this.tile36.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tile36.BackColor = System.Drawing.Color.Transparent;
            this.tile36.Location = new System.Drawing.Point(830, 547);
            this.tile36.Name = "tile36";
            this.tile36.Size = new System.Drawing.Size(110, 68);
            this.tile36.TabIndex = 53;
            this.tile36.TabStop = false;
            // 
            // tile37
            // 
            this.tile37.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tile37.BackColor = System.Drawing.Color.Transparent;
            this.tile37.Location = new System.Drawing.Point(830, 622);
            this.tile37.Name = "tile37";
            this.tile37.Size = new System.Drawing.Size(110, 78);
            this.tile37.TabIndex = 54;
            this.tile37.TabStop = false;
            // 
            // tile38
            // 
            this.tile38.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tile38.BackColor = System.Drawing.Color.Transparent;
            this.tile38.Location = new System.Drawing.Point(830, 706);
            this.tile38.Name = "tile38";
            this.tile38.Size = new System.Drawing.Size(110, 72);
            this.tile38.TabIndex = 55;
            this.tile38.TabStop = false;
            // 
            // tile39
            // 
            this.tile39.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tile39.BackColor = System.Drawing.Color.Transparent;
            this.tile39.Location = new System.Drawing.Point(830, 784);
            this.tile39.Name = "tile39";
            this.tile39.Size = new System.Drawing.Size(110, 79);
            this.tile39.TabIndex = 56;
            this.tile39.TabStop = false;
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(965, 1002);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.richTextBox5);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.displayText);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.richTextBox4);
            this.Controls.Add(this.richTextBox3);
            this.Controls.Add(this.richTextBox2);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.tile0);
            this.Controls.Add(this.tile9);
            this.Controls.Add(this.tile8);
            this.Controls.Add(this.tile7);
            this.Controls.Add(this.tile6);
            this.Controls.Add(this.tile5);
            this.Controls.Add(this.tile4);
            this.Controls.Add(this.tile3);
            this.Controls.Add(this.tile2);
            this.Controls.Add(this.tile1);
            this.Controls.Add(this.tile20);
            this.Controls.Add(this.tile19);
            this.Controls.Add(this.tile18);
            this.Controls.Add(this.tile17);
            this.Controls.Add(this.tile16);
            this.Controls.Add(this.tile15);
            this.Controls.Add(this.tile14);
            this.Controls.Add(this.tile13);
            this.Controls.Add(this.tile12);
            this.Controls.Add(this.tile11);
            this.Controls.Add(this.tile10);
            this.Controls.Add(this.tile21);
            this.Controls.Add(this.tile22);
            this.Controls.Add(this.tile23);
            this.Controls.Add(this.tile24);
            this.Controls.Add(this.tile25);
            this.Controls.Add(this.tile26);
            this.Controls.Add(this.tile27);
            this.Controls.Add(this.tile28);
            this.Controls.Add(this.tile29);
            this.Controls.Add(this.tile30);
            this.Controls.Add(this.tile38);
            this.Controls.Add(this.tile37);
            this.Controls.Add(this.tile39);
            this.Controls.Add(this.tile36);
            this.Controls.Add(this.tile35);
            this.Controls.Add(this.tile34);
            this.Controls.Add(this.tile33);
            this.Controls.Add(this.tile32);
            this.Controls.Add(this.tile31);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Form4";
            this.Text = "Form4";
            this.Load += new System.EventHandler(this.Form4_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile30)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile37)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile38)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tile39)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.RichTextBox richTextBox3;
        private System.Windows.Forms.RichTextBox richTextBox4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox displayText;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.RichTextBox richTextBox5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox tile0;
        private System.Windows.Forms.PictureBox tile1;
        private System.Windows.Forms.PictureBox tile2;
        private System.Windows.Forms.PictureBox tile3;
        private System.Windows.Forms.PictureBox tile4;
        private System.Windows.Forms.PictureBox tile5;
        private System.Windows.Forms.PictureBox tile6;
        private System.Windows.Forms.PictureBox tile7;
        private System.Windows.Forms.PictureBox tile8;
        private System.Windows.Forms.PictureBox tile9;
        private System.Windows.Forms.PictureBox tile10;
        private System.Windows.Forms.PictureBox tile11;
        private System.Windows.Forms.PictureBox tile12;
        private System.Windows.Forms.PictureBox tile13;
        private System.Windows.Forms.PictureBox tile14;
        private System.Windows.Forms.PictureBox tile15;
        private System.Windows.Forms.PictureBox tile16;
        private System.Windows.Forms.PictureBox tile17;
        private System.Windows.Forms.PictureBox tile18;
        private System.Windows.Forms.PictureBox tile19;
        private System.Windows.Forms.PictureBox tile20;
        private System.Windows.Forms.PictureBox tile21;
        private System.Windows.Forms.PictureBox tile22;
        private System.Windows.Forms.PictureBox tile23;
        private System.Windows.Forms.PictureBox tile24;
        private System.Windows.Forms.PictureBox tile25;
        private System.Windows.Forms.PictureBox tile26;
        private System.Windows.Forms.PictureBox tile27;
        private System.Windows.Forms.PictureBox tile28;
        private System.Windows.Forms.PictureBox tile29;
        private System.Windows.Forms.PictureBox tile30;
        private System.Windows.Forms.PictureBox tile31;
        private System.Windows.Forms.PictureBox tile32;
        private System.Windows.Forms.PictureBox tile33;
        private System.Windows.Forms.PictureBox tile34;
        private System.Windows.Forms.PictureBox tile35;
        private System.Windows.Forms.PictureBox tile36;
        private System.Windows.Forms.PictureBox tile37;
        private System.Windows.Forms.PictureBox tile38;
        private System.Windows.Forms.PictureBox tile39;
    }
}