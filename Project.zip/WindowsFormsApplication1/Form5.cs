﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form5 : Form
    {
        List<string> imageName;
        public Card[] Cards = new Card[6];
        public int index = 0;
        Form1.Form4 Game;

        public Form5(int playerI,Form1.Form4 game) //pass form 4 to form 5
        {
            InitializeComponent();
            Game = game;
            newCard("Pass Go", 0, 0, 0, 0); newCard("Mysterious Box", 1, 200, 0,0); newCard("Broken Bones", 2, -200, 0,0); newCard("Go to Jail", 3, 0, 0,1); newCard("Get out of Jail", 4, 0, 1,0); newCard("Night Out", 5, -100, 0,0);
            imageName = new List<string> { @"X:\My Pictures\pass go.png", @"X:\My Pictures\box.png", @"X:\My Pictures\bones.png", @"X:\My Pictures\jail.png", @"X:\My Pictures\outofjail.png" };
            index = drawCard(); //so random number doesn't change.
            pictureBox1.Image = Image.FromFile(imageName[index]); //get random index of images, sets it to picture box
            textBox1.Text = Cards[index].name; //sets name of card
            Form1.Form4.Players[playerI].cardPrice = Cards[index].price; //changes balance if pay or recieve money
            Form1.Form4.Players[playerI].outOfJail = Cards[index].outofJail; //changes if player has an outof jail card

            if (Cards[index].gotoJail == 1)
            {

                Form1.Form4.Players[playerI].inJail = true; //sends player to jail if go to jail card
            }

            if (index == 0) //if pass go card
            {
                Form1.Form4.Players[playerI].passGo = true; 
            }
        }

        public class Card
        {
            public int[] image;
            public string name;
            public int price = 0; //if user needs to pay.
            public int outofJail = 0; //0 if not, 1 if out of jail card
            public int gotoJail = 0; // =1 if its a go to jail card
        }

        public void newCard(string name, int i, int price, int outofJail, int gotoJail)
        {
            Card temp = new Card();
            temp.name = name;
            temp.price = price;
            temp.outofJail = outofJail;
            temp.gotoJail = gotoJail;
            Cards[i] = temp;
        }

        public int drawCard()
        {
            Random rand = new Random(); 
            int index = rand.Next(0, 5); 
            return index;
        }

        private void button1_Click(object sender, EventArgs e) //ok button
        {
            Game.ButtonWasClicked(); //lets function run
            this.Close();
            
        }

        private void Form5_Load(object sender, EventArgs e)
        {

        }
    }
}
