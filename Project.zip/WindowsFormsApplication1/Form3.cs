﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WindowsFormsApplication1;

namespace Form1
{
    public partial class Form3 : Form
    {

        private Menu mainmenu; //holds form1
        public int playerCount;
        public Form3(Menu menuform)
        {
            InitializeComponent();
            button2.Enabled = false;
            mainmenu = menuform; //assigns to variable
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                checkBox2.Checked = false;
                checkBox3.Checked = false;
                button2.Enabled = true;
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked == true)
            {
                checkBox1.Checked = false;
                checkBox3.Checked = false;
                button2.Enabled = true;
            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked == true)
            {
                checkBox2.Checked = false;
                checkBox1.Checked = false;
                button2.Enabled = true;
            }
        }
        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            mainmenu.Show();
            this.Close();
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            if (checkBox1.Checked == true)
            {
                playerCount = 2;
               
                Form6 form6 = new Form6(playerCount, mainmenu);
                this.Close();
                form6.Show();
                
            }
          else  if (checkBox2.Checked == true)
            {
                
                int  playerCount = 3;
                Form6 form6 = new Form6(playerCount, mainmenu);
                this.Close();
                form6.Show();
            }
          else  if (checkBox3.Checked == true)
            {
                playerCount = 4;
                Form6 form6 = new Form6(playerCount, mainmenu);
                this.Close();
                form6.Show();
            }
            
            //start main game window
            //close this form
        }

    }
}
