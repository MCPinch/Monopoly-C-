﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
namespace Form1
{
    public partial class Menu : Form
    {
        public int playerCount;
        public Menu()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            FormBorderStyle = FormBorderStyle.None;
            WindowState = FormWindowState.Maximized;
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3(this);//pass form1 to form 3
            this.Hide();
            form3.Show();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e) //Exit button
        {
            DialogResult dialog = MessageBox.Show("Do you really want to exit the program?", "Exit"
            ,MessageBoxButtons.YesNo); //creates message box with yes/no options

            if(dialog == DialogResult.Yes)
            {
                Application.Exit(); //exits program
            }
            else if (dialog == DialogResult.No)
            {
                return; //overrides the button click event
            }
          
        }

      
    }
}
