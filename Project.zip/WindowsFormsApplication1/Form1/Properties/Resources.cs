﻿namespace Form1.Properties
{
    internal class Resources
    {
    }
}