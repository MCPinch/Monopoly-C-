﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WindowsFormsApplication1;

namespace Form1
{
    public partial class Form4 : Form
    {
        private Menu mainmenu;
        public int rent;
        public int turn = 0;
        public int[] position = new int[] { 0, 0, 0, 0 };
        public String PlayerCountS;
        public bool passedGo;
        public int currentPosition;
        public static Property[] Properties = new Property[40]; //initialise array of properties
        public static Player[] Players = new Player[4]; //Array to initialise player's values
        public static int CardClosed = 0; //check if card window is closed 

        public class Property
        {
            public int Owner;
            public int value;
            public string colour;
            public bool owned = false;
            public string Name;
            public int rent;
            public bool buyable;
        }

     
        
        public class Player
        {
            public int[] PropertiesOwned = new int[40]; //properties player owns 
            public int balance = 1500;
            public int cardPrice = 0;
            public bool passGo = false; // check if card is passgo
            public int numberofpropertiesOwned = 0;
            public int Jail = 0; //To tell how many turns spent in jail
            public bool inJail = false;
            //  public int DoubleCount = 0;  //amount of doubles rolles, if a double is rolled they get out of jail
            public int outOfJail = 0; //get out of jail card
            public string playerName;
            public Boolean loser = false; // lose game set to false for each player
            public string playerImageName; //player icon
        }

        public void RegisterPlayer(string playerName, int i, bool inJail)
        {
            Player temp = new Player();
            temp.playerName = playerName;
            temp.inJail = inJail;
            Players[i] = temp;
        }

        public void RegisterProperty(string Name, bool buyable, string colour, int value, int location)
        {
            Property temp = new Property();
            temp.Name = Name;
            temp.colour = colour;
            temp.buyable = buyable;
            temp.value = value;
            Properties[location] = temp;
            
        }
        public bool diceRoll;
        private int Dice;

        public void RollDice()
        {
            if (diceRoll == true) //IF myTurn == True && inJail == false
            {
                Random rand = new Random(); //CANT ROLL 1 CAN MIN ROLL 2 FIX!!!
                Dice = rand.Next(2, 13); //sets Dice to random number between 1 and 12
                return;
            }
        }

        public int CalcPlayerTurn(string playerCountS)
        {

            int playerCount = System.Convert.ToInt32(playerCountS); //converts back to int
            int currentPlayer = 1;

            for (int x = 1; x <= turn; x++)
            {
                currentPlayer++;
                if (currentPlayer > playerCount)
                {
                    currentPlayer = 1;

                }

            }
            return currentPlayer;
        
        }
        public  PictureBox[] tile; //make array fot tiles public
        public Form4(string playerCountS, Menu menu, string []playerspieces, int playerCount)
        {
            InitializeComponent();
            tile = new PictureBox[] { tile0, tile1, tile2, tile3, tile4, tile5, tile6, tile7, tile8, tile9, tile10, tile11, tile12, tile13, tile14, tile15, tile16, tile17 , tile18, tile19, tile20, tile21, tile22, tile23, tile24, tile25, tile26, tile27, tile28, tile29, tile30, tile31, tile32, tile33, tile34, tile35, tile36, tile37, tile38, tile39 }; //array for each tile picture box
            mainmenu = menu;
            PlayerCountS = playerCountS;
            textBox1.Text = "Player 1's turn. To start, press the roll button."; //info to start game
            RegisterProperty("GO", false, "Null", 0, 0); RegisterProperty("Old Dust Road", true, "Brown", 60, 1); RegisterProperty("Community Chest", false, "Card", 0, 2); RegisterProperty("DarkChapel Road", true, "Brown", 60, 3); RegisterProperty("Pay 200", false, "Null", 0, 4); RegisterProperty("Kings Head Station", true, "Station", 200, 5); RegisterProperty("Pentonville Road", true, "Purple", 100, 6); RegisterProperty("Chance", false, "Card", 0, 7); RegisterProperty("Angel Square", true, "Purple", 100, 8); RegisterProperty("Cobweb Close", true, "Purple", 120, 9); RegisterProperty("Jail", false, "Null", 0, 10); RegisterProperty("Pain Mall", true, "Pink", 140, 11); RegisterProperty("Electrics", true, "Utility", 150, 12); RegisterProperty("Black Cat Drive", true, "Pink", 140, 13); RegisterProperty("Bones Lane", true, "Pink", 160, 14); RegisterProperty("Spooky Station", true, "Station", 200, 15); RegisterProperty("Cauldron Cresent", true, "Orange", 180, 16); RegisterProperty("Community Chest", false, "Card", 0, 17); RegisterProperty("Devils Lane", true, "Orange", 180, 18); RegisterProperty("Vine Street", true, "Orange", 180, 19); RegisterProperty("Free Parking", false, "Null", 0, 20); RegisterProperty("Spook Hill", true, "Red", 220, 21); RegisterProperty("Chance", false, "Card", 0, 22); RegisterProperty("Fleet Street", true, "Red", 220, 23); RegisterProperty("Reapers Close", true, "Red", 240, 24); RegisterProperty("Slasher Station", true, "Station", 200, 25); RegisterProperty("Broomstick Square", true, "Yellow", 260, 26); RegisterProperty("Spider Street", true, "Yellow", 260, 27); RegisterProperty("Water Works", true, "Utility", 150, 28); RegisterProperty("Headless Close", true, "Yellow", 280, 29); RegisterProperty("Go To Jail", false, "Null", 0, 30); RegisterProperty("Blood Street", true, "Green", 300, 31); RegisterProperty("Purgatory Road", true, "Green", 300, 32); RegisterProperty("Community Chest", false, "Card", 0, 33); RegisterProperty("Bond Street", true, "Green", 320, 34); RegisterProperty("Spirit Station", true, "Station", 200, 35); RegisterProperty("Chance", false, "Card", 0, 36); RegisterProperty("Howling Lane", true, "Blue", 350, 37); RegisterProperty("Pay 200", false, "Null", 0, 38); RegisterProperty("Skull House Square", true, "Blue", 400, 39);
            RegisterPlayer("Player 1", 0, false);
            RegisterPlayer("Player 2", 1, false);
            RegisterPlayer("Player 3", 2, false);
            RegisterPlayer("Player 4", 3, false);
            for (int i = 0; i < playerCount; i++)
            {
                Players[i].playerImageName = playerspieces[i+1];
            }
            updateTextBox();
            button3.Enabled = false;
            button2.Enabled = false;
           
        }

        public string PropertiestoString(int[] propertyList) //changes each property so value of properties owned is a string.
        {
            string tempString = "";
            for (int i = 0; i < 40; i++)
            {
                if (propertyList[i] != 0) //check if player is on go
                {
                    tempString = tempString + Properties[propertyList[i]].Name + ", " + Properties[propertyList[i]].colour + "\n"; //looping through properties the player owns and getting the name of each.
                                                                                                                                   //add new line so it can be read easily

                }
            }
            return tempString;
        }


        public void updateTextBox() //updates what info boxes say
        {
            richTextBox1.Text = Players[0].playerName + "\n" + Players[0].playerImageName +"\n"+ Players[0].balance + "\n" + PropertiestoString(Players[0].PropertiesOwned);
            richTextBox2.Text = Players[1].playerName + "\n" + Players[1].playerImageName + "\n"+Players[1].balance + "\n" + PropertiestoString(Players[1].PropertiesOwned);
            richTextBox3.Text = Players[2].playerName + "\n" + Players[2].playerImageName + "\n"+Players[2].balance + "\n" + PropertiestoString(Players[2].PropertiesOwned);
            richTextBox4.Text = Players[3].playerName + "\n" + Players[3].playerImageName + "\n"+Players[3].balance + "\n" + PropertiestoString(Players[3].PropertiesOwned);
            richTextBox1.AppendText("Out of jail card - " + Players[0].outOfJail + "\n");
            richTextBox2.AppendText("Out of jail card - " + Players[1].outOfJail + "\n");
            richTextBox3.AppendText("Out of jail card - " + Players[2].outOfJail + "\n");
            richTextBox4.AppendText("Out of jail card - " + Players[3].outOfJail + "\n");
           
        }

        public void changeBalance(Player player, int cashChange)
        {
            player.balance += cashChange;
            updateTextBox();
        }

        public void movePicture(int position)
        {
            switch (Players[CalcPlayerTurn(PlayerCountS) - 1].playerImageName) //sets what picture box the player uses
            {
                case "Ghost":
                    int x = tile[position].Location.X;
                    int y = tile[position].Location.Y;

                    pictureBox1.Location = new Point(x,y);
                    
                    break;
                case "Hat":
                     x = tile[position].Location.X;
                     y = tile[position].Location.Y;

                    pictureBox2.Location = new Point(x, y);
                    break;
                case "Pumpkin":
                    x = tile[position].Location.X;
                    y = tile[position].Location.Y;

                    pictureBox3.Location = new Point(x, y);
                    break;
                case "Skull":
                    x = tile[position].Location.X;
                    y = tile[position].Location.Y;

                    pictureBox4.Location = new Point(x, y);
                    break;
                default: //error message
                    textBox1.Text = "error!";
                    break;

            }
        }


        private void button1_Click(object sender, EventArgs e) //roll button
        {
            button2.Enabled = true;
            updateTextBox();
            button3.Enabled = false;
            displayText.Text = ""; //each time button is pressed, resets value
            diceRoll = true; //diceRoll true when Roll button is pressed
            RollDice();
            displayText.Text += "You rolled" + " " + Dice; //prints number
            diceRoll = false;
            button1.Enabled = false; //can only be rolled once per turn.
            
            int currentPlayer = CalcPlayerTurn(PlayerCountS) - 1; //returns current player value
            currentPosition = position[currentPlayer] + Dice; //index according to current player
          /*  if (Properties[currentPosition].Owner == currentPlayer)
            {
               button2.Enabled = false; 
            }*/
            if (Players[currentPlayer].inJail == true) //jail square
            {
                inJail(currentPlayer);
            }
            if ((currentPosition == 10)&&(Players[currentPlayer].inJail == false))
            {
                button2.Enabled = false; 
            }
            if (currentPosition >= 40)
            {

                changeBalance(Players[currentPlayer], 200); //add 200 when pass go
                position[currentPlayer] = currentPosition - 40;
                currentPosition = position[currentPlayer];
            }

            if (Properties[currentPosition].colour == "Card") //if on card square
            {
                button1.Enabled = false; //roll button disabled
                button2.Enabled = false;
                button5.Enabled = false; //end turn button disabled
                button3.Enabled = true; //draw card button eanbled
            }

            if ((currentPosition == 4) || (currentPosition == 38))
            { //deducts money when land on pay 200 square...

                changeBalance(Players[currentPlayer], -200);
            }

            if (currentPosition == 30) // go to jail square
            {
                currentPosition = 10; //jail square
                movePicture(currentPosition);
                Players[currentPlayer].inJail = true;
                inJail(currentPlayer);
            }



            position[currentPlayer] = currentPosition; //value at index is changed each time to hold position
            richTextBox5.Text = "Position " + currentPosition;
            richTextBox5.AppendText("\r\n" + Properties[currentPosition].Name);
            richTextBox5.AppendText("\r\n" + "Value " + Properties[currentPosition].value);
            richTextBox5.AppendText("\r\n" + "Type " + Properties[currentPosition].colour);
            richTextBox5.ScrollToCaret();

            if (checkifOwned(currentPlayer, currentPosition) == false)
            {
                changeBalance(Players[currentPlayer], -GetRent(Dice)); //deduct rent
                changeBalance(Players[Properties[currentPosition].Owner], GetRent(Dice)); // add rent to owner
            }
         

            movePicture(currentPosition); //Inside roll function, moves player piece to correct position

            if (Players[currentPlayer].loser == true || Players[currentPlayer].balance <= 0) //If players have lost or have no money
            {
                Lose(); //Locked out the game
            }
            int playerCount = System.Convert.ToInt32(PlayerCountS);
            int count = 0;
            for ( int i =0; i<playerCount; i++) //loops through players to check if they have lost
            {
                if(Players[i].loser == true)
                {
                    count++;
                }
                if(Players[currentPlayer].loser == false && count >= playerCount - 1)
                {
                    textBox1.Text = "You have won! Congratulations!";
                    DialogResult dialog = MessageBox.Show("Player" + currentPlayer + " Has won the game!", "GAME OVER", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    
                    if(dialog == DialogResult.OK)
                    {
                        this.Hide();
                        mainmenu.Show(); 
                    }
                }
            }
            
            textBox1.Text = "Player" + CalcPlayerTurn(PlayerCountS).ToString() + "\r\n" + Players[CalcPlayerTurn(PlayerCountS) - 1].playerImageName;
        }

        public bool checkifOwned(int currentPlayer, int currentPosition)
        {
            if ((Players[currentPlayer].PropertiesOwned[currentPosition] != currentPosition) && (Properties[currentPosition].owned == true))
                {
                return false;
            }
                else
                {
                return true;
            }
        
        }

        public void inJail(int currentPlayer)
        {
            textBox1.Text = "You are in jail! Press buy button to get out or wait 3 turns...";
            Players[currentPlayer].Jail = Players[currentPlayer].Jail + 1; //adds one turn in jail
            button1.Enabled = false; //cant roll
            if((Players[currentPlayer].Jail == 3) || (Players[currentPlayer].outOfJail == 1))
            {
                Players[currentPlayer].inJail = false;
                button1.Enabled = true; // can roll after 3 turns
                Players[currentPlayer].outOfJail = 0; //remove out of jail card once used 
               
            }

        }

        public int GetRent(int Dice)
        {
            switch (Properties[currentPosition].colour) //get rent of current property depending on colour type
            {
                case "Null":
                    Properties[currentPosition].rent = 0;
                    break;
                case "Brown":
                    Properties[currentPosition].rent = 4;
                    break;
                case "Card":
                    Properties[currentPosition].rent = 0;
                    break;
                case "Station":
                    Properties[currentPosition].rent = 25;
                    break;
                case "Utility":
                    Properties[currentPosition].rent = Dice * 4;
                    break;
                case "Purple":
                    Properties[currentPosition].rent = 8;
                    break;
                case "Pink":
                    Properties[currentPosition].rent = 12;
                    break;
                case "Orange":
                    Properties[currentPosition].rent = 16;
                    break;
                case "Red":
                    Properties[currentPosition].rent = 20;
                    break;
                case "Yellow":
                    Properties[currentPosition].rent = 22;
                    break;
                case "Green":
                    Properties[currentPosition].rent = 28;
                    break;
                case "Blue":
                    Properties[currentPosition].rent = 50;
                    break;
            }
            return Properties[currentPosition].rent;
        }

        private void button2_Click(object sender, EventArgs e)//buy button
        {
            int currentPlayer = CalcPlayerTurn(PlayerCountS) - 1;
            if ((Properties[currentPosition].buyable == true) && (Properties[currentPosition].owned == false)) //so player can't buycard/go sqaures
            {
                if (Players[currentPlayer].balance >= Properties[currentPosition].value) //checks that player has enough.
                {
                    changeBalance(Players[currentPlayer], -Properties[currentPosition].value); //change function call to - to take away
                    Players[currentPlayer].PropertiesOwned[Players[currentPlayer].numberofpropertiesOwned] = currentPosition; //Adds current position of player(property player is on) to properties owned at the number of properties owned by that player(index).
                    Properties[currentPosition].owned = true; //so rent can be payed
                    Properties[currentPosition].Owner = currentPlayer; //sets owner of property
                    Players[currentPlayer].numberofpropertiesOwned++; //next available space in array
                    updateTextBox();
                    button2.Enabled = false;
                }
            }

            else if ((currentPosition == 10) && (Players[currentPlayer].inJail == true)) //if in jail when buy button pressed
            {
                changeBalance(Players[currentPlayer], -100); // pay fine
                button2.Enabled = false; //can't pay more than once.
                button1.Enabled = true;
                Players[currentPlayer].inJail = false;
            }

            else
            {
                textBox1.Text = "NOT ENOUGH MONEY! OR UNAVAILABLE";
            }
            if (Players[currentPlayer].balance <= 0)
            {
                Lose();
            }
            
        }

        private void button3_Click(object sender, EventArgs e) //draw card button
        {
            Form5 form5 = new Form5(CalcPlayerTurn(PlayerCountS) - 1,this);
            form5.Show();
            button3.Enabled = false;
            //open card form
        }

        public void ButtonWasClicked() //check ok button in form5 was clicked
        {
            button5.Enabled = true; 
            changeBalance(Players[CalcPlayerTurn(PlayerCountS) - 1], Players[CalcPlayerTurn(PlayerCountS) - 1].cardPrice);
            if (Players[CalcPlayerTurn(PlayerCountS) - 1].balance <= 0)
            {
                Lose();
            }

            if (Players[CalcPlayerTurn(PlayerCountS) - 1].inJail == true)
            {
                currentPosition = 10;
                movePicture(currentPosition); // moves player image
                position[CalcPlayerTurn(PlayerCountS) -1] = currentPosition;
                inJail(CalcPlayerTurn(PlayerCountS) - 1); //check if player is in jail
                button2.Enabled = true;
            }
            if (Players[CalcPlayerTurn(PlayerCountS) - 1].passGo == true)
            {
                position[CalcPlayerTurn(PlayerCountS) - 1] = 0;
                movePicture(0);
            }
        }

        private void button4_Click(object sender, EventArgs e) //quit button
        {
            mainmenu.Show();
            this.Close();
        }

        private void button5_Click(object sender, EventArgs e) //end turn button
        {
            turn = turn + 1;
            textBox1.Text = "Player" + CalcPlayerTurn(PlayerCountS).ToString() + "\r\n" + Players[CalcPlayerTurn(PlayerCountS) - 1].playerImageName;
            button1.Enabled = true;
            button2.Enabled = false;

            if (Players[CalcPlayerTurn(PlayerCountS) - 1].inJail == true)
            {
                currentPosition = 10;
                movePicture(currentPosition); // moves player image
                position[CalcPlayerTurn(PlayerCountS) - 1] = currentPosition;
                inJail(CalcPlayerTurn(PlayerCountS) - 1);
            }

            if (Players[CalcPlayerTurn(PlayerCountS) - 1].loser == true || Players[CalcPlayerTurn(PlayerCountS) - 1].balance <= 0) //If players have lost or have no money
            {
                Lose(); //Locked out the game
            }
            int playerCount = System.Convert.ToInt32(PlayerCountS);
            int count = 0;
            for (int i = 0; i < playerCount; i++) //loops through players to check if they have lost
            {
                int currentPlayer = CalcPlayerTurn(PlayerCountS) ;
                if (Players[i].loser == true)
                {
                    count++;
                }
                if (Players[CalcPlayerTurn(PlayerCountS) - 1].loser == false && count >= playerCount - 1)
                {
                    textBox1.Text = "You have won! Congratulations!";
                    DialogResult dialog = MessageBox.Show("Player" + currentPlayer + " Has won the game!", "Title", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    if (dialog == DialogResult.OK)
                    {
                        this.Hide();
                        mainmenu.Show();
                    }
                }
            }
        }

        public void Lose() //locks player out / loses game
        {
            Players[CalcPlayerTurn(PlayerCountS) - 1].loser = true;
            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = false;
            textBox1.Text = "You have lost the game!";
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

     
    }
}
