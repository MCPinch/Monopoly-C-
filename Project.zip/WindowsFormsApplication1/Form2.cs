﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Form1
{
    public partial class Form2 : Form
    {
        List<string> imageName;

        public int counter = 0;
        public Form2()
        {
            InitializeComponent();
            imageName = new List<string> { @"X:\My Pictures\buyproperty.PNG", @"X:\My Pictures\own property.PNG", @"X:\My Pictures\passGo.PNG", @"X:\My pictures\cards.PNG",  @"X:\My pictures\jailhelp.PNG", @"X:\My Pictures\email.PNG" };
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            var image = Image.FromFile(imageName[0]);

            pictureBox1.Image = image;
            button2.Enabled = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {

            counter = counter + 1;

            Image image = Image.FromFile(imageName[counter]);

            pictureBox1.Image = image;

            if (counter > 0)

            {

                button2.Enabled = true;

            }

            if (counter == imageName.Count - 1)

            {

                button1.Enabled = false;
            }




        }

        private void button2_Click(object sender, EventArgs e)
        {
            counter = counter - 1;

            Image image = Image.FromFile(imageName[counter]);

            pictureBox1.Image = image;

            if (counter == 0)

            {

                button2.Enabled = false;

            }

            if (counter < imageName.Count)

            {

                button1.Enabled = true;

            }


        }
    }
}